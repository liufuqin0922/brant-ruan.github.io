#ifndef STDDEF_H
#define STDDEF_H

#define NULL 0

#endif
