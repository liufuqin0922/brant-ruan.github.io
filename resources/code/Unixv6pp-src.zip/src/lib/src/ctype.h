#ifndef CTYPE_H
#define CTYPE_H

#define isdigit(Ch) ( (Ch) >= '0' && (Ch) <= '9' )

#endif

