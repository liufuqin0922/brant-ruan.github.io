#ifndef TEST_UTILITY_H
#define TEST_UTILITY_H

void PrintResult(char* casename, bool result);

#endif