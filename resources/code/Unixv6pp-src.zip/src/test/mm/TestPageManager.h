#ifndef TEST_PAGEMANAGER_H
#define TEST_PAGEMENAGER_H

bool TestPageManager();

#endif